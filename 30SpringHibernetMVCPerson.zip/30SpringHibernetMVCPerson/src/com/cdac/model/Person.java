package com.cdac.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table(name="MYPERSON")
public class Person {
	@Id
	@Column(name="person_Id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	private Integer personId;
	
	@Size(max =20,min =2,message="Enter valid Name")
	String name;
	
	@NotEmpty(message="Invalid Country Name")
	String country;

	public Integer getPersonId() {
		return personId;
	}

	public void setPersonId(Integer personId) {
		this.personId = personId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "Person [personId=" + personId + ", name=" + name + ", country=" + country + "]";
	}
	
}
