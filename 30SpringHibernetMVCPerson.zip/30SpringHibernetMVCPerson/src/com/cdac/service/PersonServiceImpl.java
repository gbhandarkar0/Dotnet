package com.cdac.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cdac.dao.IPersonDao;
import com.cdac.model.Person;

public class PersonServiceImpl implements IPersonService {

	private IPersonDao personDao;
	
	@Autowired
	public void setPersonDao(IPersonDao personDao) {
		this.personDao = personDao;
	}

	@Override
	@Transactional
	public Person addPerson(Person person) {
		// TODO Auto-generated method stub
	
		return this.personDao.addPerson(person);
	}

	@Override
	@Transactional
	public Person updatePerson(Person person) {
		// TODO Auto-generated method stub
		return this.personDao.updatePerson(person);
	}

	@Override
	@Transactional
	public List<Person> listPersons() {
		// TODO Auto-generated method stub
		return this.personDao.listPersons();
	}

	@Override
	@Transactional
	public Person getPersonById(int id) {
		// TODO Auto-generated method stub
		return this.personDao.getPersonById(id);
	}

	@Override
	@Transactional
	public Person removePersonById(int id ) {
		return this.personDao.getPersonById(id);
	}

}
