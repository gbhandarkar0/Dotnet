package com.cdac.service;

import java.security.Permissions;
import java.util.List;

import com.cdac.model.Person;

public interface IPersonService {

	public Person addPerson(Person person);
	public Person updatePerson(Person person);
	public List<Person>listPersons();
	public Person getPersonById(int id);
	public Person removePersonById(int id);


}
