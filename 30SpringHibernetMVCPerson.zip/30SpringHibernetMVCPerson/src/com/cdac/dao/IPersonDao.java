package com.cdac.dao;

import java.util.List;

import com.cdac.model.Person;

public interface IPersonDao {

	public Person addPerson(Person person);//insert
	public Person updatePerson(Person person);//update
	public List<Person> listPersons();//retrive/listall
	public Person getPersonById(int id);//search
	public Person removePersonById(int id);//delete/remove
}
