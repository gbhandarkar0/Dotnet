package com.cdac.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cdac.model.Person;

public class PersonDaoImpl implements IPersonDao {

	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	public Person addPerson(Person person) {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		session.persist(person);
		return person;
	}

	@Override
	public Person updatePerson(Person person) {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		session.update(person);
		return person;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Person> listPersons() {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		List<Person> personList=session.createQuery("from Person").list();
		
		for(Person p:personList)
		{
			
		}
		return personList;
	}

	@Override
	public Person getPersonById(int id) {
		Session session=this.sessionFactory.getCurrentSession();
		Person p=(Person) session.load(Person.class,new Integer(id));
		
		return p;
		// TODO Auto-generated method stub
		
	}

	@Override
	public Person removePersonById(int id) {
		
		Session session=this.sessionFactory.getCurrentSession();
		Person p=(Person) session.load(Person.class,new Integer(id));
		return p;
		// TODO Auto-generated method stub
		
	}
	
	
}
